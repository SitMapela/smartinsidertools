# Smart Insider Tools — Company Website

Official website for **Smart Insider Tools (Pty) Ltd** (Reg. 2025/207836/07), a South African construction and professional services company based in Mapela/Mokopane, Limpopo.

## 🌐 Live Site
Deploy via GitHub Pages: `Settings → Pages → Deploy from main branch → / (root)`

## 📁 Structure
```
├── index.html       # Main website (self-contained, logo embedded)
├── assets/
│   └── logo.png     # Smart Insider Tools logo
└── README.md
```

## 🏗️ Services
- General Construction
- Electrical Works
- Plumbing Services
- Steel & Structural Works
- Project Management
- Tax & Compliance

## 📞 Contact
- **Email:** sit.mapela@gmail.com
- **Phone:** 073 291 4050
- **Location:** Mapela / Mokopane, Limpopo Province

## ⚙️ Tech
Plain HTML/CSS — no frameworks, no build tools. Open `index.html` in any browser.

---
© 2025 Smart Insider Tools (Pty) Ltd
